/******************************************************************************/
/**
 * @file    Orchestrator.cpp
 * @addtogroup ORCHESTRATOR
 * @brief   Implementacao do Orquestrador: gestao do pipeline, unificacao da ROI e HUD.
 * @author  Gonçalves
 * @details
 * \n <b>Regra de Arquitetura:</b> Fonte Unica da Verdade (Single Source of Truth).
 * \n O enquadramento central (ROI) e calculado exclusivamente aqui. Qualquer
 *    alteracao de tamanho nesta constante altera tanto o desenho quanto o filtro.
 *
 * @{
 ******************************************************************************/

/*******************************************************************************
 * INCLUDES
 ******************************************************************************/
#include "Orchestrator.hpp"
#include "CameraModule.hpp"
#include "VisionModule.hpp"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>

/*******************************************************************************
 * CONSTANTES DE CONFIGURACAO DA ZONA DE INSPECAO (FONTE UNICA DA VERDADE)
 ******************************************************************************/

/** @brief Proporcao da largura da Zona de Inspecao em relacao ao frame total (50%). */
static constexpr float dROI_SCALE_X = 0.25f;

/** @brief Proporcao da altura da Zona de Inspecao em relacao ao frame total (50%). */
static constexpr float dROI_SCALE_Y = 0.25f;

/*******************************************************************************
 * PROTOTIPOS LOCAIS
 ******************************************************************************/
static cv::Rect ObterEnquadramentoInspecao(const cv::Size& frameSize);
static std::string ObterNomeForma(int classId);

/*******************************************************************************
 * FUNCOES PUBLICAS
 ******************************************************************************/

/******************************************************************************/
/**
 * @brief  Realiza a inicializacao coordenada dos modulos de Visao e Camera.
 * @param  modelPath Caminho para o arquivo ONNX treinado.
 * @param  cameraSN Numero de serie opcional da camera.
 * @return true se ambos os modulos responderem com sucesso; false caso contrario.
 ******************************************************************************/
bool Orchestrator_Init(const std::string& modelPath, const std::string& cameraSN)
{
    // Habilita processamento multi-core paralelo para as rotinas graficas do OpenCV
    cv::setNumThreads(8);

    std::cout << "[ORCHESTRATOR] Inicializando subsistemas..." << std::endl;

    if (!Vision_Init(modelPath))
    {
        std::cerr << "[ORCHESTRATOR] Falha critica ao inicializar VisionModule." << std::endl;
        return false;
    }

    if (!Camera_Init(cameraSN))
    {
        std::cerr << "[ORCHESTRATOR] Falha critica ao inicializar CameraModule." << std::endl;
        return false;
    }

    std::cout << "[ORCHESTRATOR] Todos os subsistemas prontos para execucao." << std::endl;
    return true;
}

/******************************************************************************/
/**
 * @brief  Loop principal de orquestracao e renderizacao do HUD na tela.
 * @return void
 * @details Executa os seguintes passos a cada ciclo:
 * \n 1. Recupera o quadro mais recente da camera industrial.
 * \n 2. Envia o quadro para a thread da IA (VisionModule).
 * \n 3. Recupera as caixas detectadas na ultima inferencia disponivel.
 * \n 4. Calcula a Zona de Inspecao centralizada.
 * \n 5. Avalia cada objeto: se o centroide estiver dentro da zona, renderiza:
 *       - Verde + Nome da Forma: para formas treinadas e reconhecidas.
 *       - Vermelho + "Nao detectada": para anomalias ou formas nao cadastradas.
 ******************************************************************************/
void Orchestrator_Run(void)
{
    Vision_Start();
    Camera_Start();

    cv::namedWindow("SICOV - Inspecao de Formas Geometricas", cv::WINDOW_NORMAL);

    cv::Mat frame;
    std::vector<DetectionResult> detections;

    std::cout << "[ORCHESTRATOR] Pipeline ativo. Pressione ESC na janela de video para finalizar." << std::endl;

    while (true)
    {
        // 1. Obtem o quadro gerado pelo produtor
        if (Camera_GetFrame(frame))
        {
            // 2. Submete o frame para analise em background
            Vision_SubmitFrame(frame);

            // 3. Coleta os ultimos resultados produzidos pela IA
            Vision_GetOverlay(detections);

            // 4. Calcula as coordenadas da Zona de Inspecao central
            cv::Rect roi = ObterEnquadramentoInspecao(frame.size());

            // Desenha a moldura da Zona de Inspecao na tela (Amarelo / BGR: 0, 255, 255)
            cv::rectangle(frame, roi, cv::Scalar(0, 255, 255), 2);
            cv::putText(frame, "ZONA DE INSPECAO", cv::Point(roi.x, roi.y - 10),
                        cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 255), 1);

            // 5. Avalia e renderiza as deteccoes
            for (const auto& det : detections)
            {
                // Calcula o centroide geometrico da caixa delimitadora
                cv::Point center(det.box.x + det.box.width / 2, det.box.y + det.box.height / 2);

                // Regra de enquadramento: filtra apenas alvos cujo centro esteja na Zona de Inspecao
                if (roi.contains(center))
                {
                    cv::Scalar boxColor;
                    std::string labelText;

                    if (det.isValid)
                    {
                        // Forma valida: Verde puro (BGR: 0, 255, 0)
                        boxColor = cv::Scalar(0, 255, 0);
                        labelText = ObterNomeForma(det.classId);
                    }
                    else
                    {
                        // Anomalia / Fora do catalogo: Vermelho puro (BGR: 0, 0, 255)
                        boxColor = cv::Scalar(0, 0, 255);
                        labelText = "Nao detectada";
                    }

                    // Renderiza o retangulo de contorno da forma geometrica
                    cv::rectangle(frame, det.box, boxColor, 2);

                    // Renderiza o texto informativo sobre a caixa (ajustado sem o y5 e sem o traco solto)
                    cv::Point textPos(det.box.x, std::max(20, det.box.y - 5));
                    cv::putText(frame, labelText, textPos, cv::FONT_HERSHEY_SIMPLEX, 0.6, boxColor, 2);
                }
            }

            cv::imshow("SICOV - Inspecao de Formas Geometricas", frame);
        }

        // Aguarda evento de teclado (1 ms) e encerra se a tecla ESC (ASCII 27) for pressionada
        if (cv::waitKey(1) == 27)
        {
            break;
        }
    }

    Orchestrator_Stop();
}

/******************************************************************************/
/**
 * @brief  Finaliza todas as threads ativas e destroi as janelas da aplicacao.
 * @return void
 ******************************************************************************/
void Orchestrator_Stop(void)
{
    std::cout << "[ORCHESTRATOR] Parando servicos..." << std::endl;
    Camera_Stop();
    Vision_Stop();
    cv::destroyAllWindows();
    std::cout << "[ORCHESTRATOR] Sistema encerrado com seguranca." << std::endl;
}

/*******************************************************************************
 * FUNCOES LOCAIS
 ******************************************************************************/

/******************************************************************************/
/**
 * @brief  Calcula dinamicamente a ROI central baseada na resolucao do frame.
 * @param  frameSize Estrutura contendo largura e altura do quadro de video.
 * @return cv::Rect Retangulo com posicao (x, y) e dimensoes (w, h) da area central.
 * @details Centraliza o retangulo na tela calculando o ponto de inicio:
 *          x = (largura_total - largura_roi) / 2
 *          y = (altura_total - altura_roi) / 2
 ******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/**
 * @brief  Calcula a Zona de Inspecao com compensacao vertical para a bancada.
 * @param  frameSize Largura e altura nativas da imagem da camera.
 * @return cv::Rect Retangulo amarelo posicionado no centro visual.
 ******************************************************************************/
static cv::Rect ObterEnquadramentoInspecao(const cv::Size& frameSize)
{
    // Dimensoes da caixa (25% do quadro)
    int w = static_cast<int>(frameSize.width * 0.25f);
    int h = static_cast<int>(frameSize.height * 0.25f);

    // Centro horizontal perfeito
    int x = (frameSize.width - w) / 2;

    // Centro vertical com deslocamento para cima (-250 pixels)
    int y = ((frameSize.height - h) / 2) - 250;

    // Protecao para nao sair dos limites superiores da imagem
    if (y < 20) y = 20;

    return cv::Rect(x, y, w, h);
}

/******************************************************************************/
/**
 * @brief  Traduz o ID numerico da classe para o nome correspondente da forma.
 * @param  classId Identificador numérico retornado pelo modelo neural.
 * @return std::string com o nome em portugues da forma geometrica.
 ******************************************************************************/
static std::string ObterNomeForma(int classId)
{
    switch (classId)
    {
        case 0: return "Circulo";
        case 1: return "Hexagono";
        case 2: return "Losango";
        case 3: return "Quadrado";
        case 4: return "Retangulo";
        case 5: return "Triangulo";
        default: return "Nao detectada";
    }
}

/** @} DOXYGEN GROUP TAG END OF FILE */